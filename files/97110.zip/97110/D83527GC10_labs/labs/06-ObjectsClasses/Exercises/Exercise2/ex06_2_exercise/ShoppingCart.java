

package ex06_2_exercise;

public class ShoppingCart {

     public static void main(String args[]) {
        // Declare and initialize 2 Item objects

	

	// Print both item descriptions and run code.


	// Assign one item to another and run it again.

     }
 
} 
