package ex11_4_exercise;

public class ShoppingCart {
    public static void main(String[] args){   
        // Declare, instantiate, and initialize an ArrayList of Strings.  Print and test your code.
        
        
        // add (insert) another element at a specific index


	// Check for the existence of a specific String element.  
        //   If it exists, remove it.
        
    }
}
