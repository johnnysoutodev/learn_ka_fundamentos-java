Exercise 3-1

1.  Click the New button to create a new Java class.  In the wizard, select Java > Java Class.
2.  Name the class ShoppingCart and enter ex03_1_exercise for a Package name.
3.  Add a main method inside the curly braces using the following syntax:
     public static void main (String[] args){
     }
4.  Within the main method, print a message to the output using the following syntax:
     System.out.println("< your message here >");
5.  Click the Run button to test your code.  You should see your message in the Output tab.
     
   Troubleshooting Tips:
   Did you end the line of code that prints the message with a semicolon?
   Did you enclose the main method in curly braces?
   Did you enclose the message String with double quotes? 
   Did you use open and closed square brackets after String? 