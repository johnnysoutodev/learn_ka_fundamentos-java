
package ex08_1_exercise;

public class Item {
    char color;
    
    // declare and code the setColor method
    
    
}
