
package ex04_1_exercise;

public class ShoppingCart {
    
    public static void main(String[] args) {
         // Declare and initialize String variables.  Do not initialize message yet.
        
        
 
 
        
        
        // Assign the message variable 

        
        // Print and run the code
        

    }
    
}
