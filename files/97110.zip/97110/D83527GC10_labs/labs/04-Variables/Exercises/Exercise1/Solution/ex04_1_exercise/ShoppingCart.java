
package ex04_1_exercise;

public class ShoppingCart {

    public static void main(String[] args) {
        // Declare and initialize String variables.  Do not initialize message yet.
        String custName = "Mary Smith";
        String itemDesc = "Shirt";
        String message;
        
        // Assign the message variable 
        message = custName+" wants to purchase a "+itemDesc;
        
	// Print the message and then run the code.
        System.out.println(message);
    }
    
}
