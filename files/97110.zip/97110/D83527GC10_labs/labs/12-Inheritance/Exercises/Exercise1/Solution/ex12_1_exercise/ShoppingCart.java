package ex12_1_exercise;

public class ShoppingCart {

    public static void main(String[] args) {
        // instantiate a Shirt object and call the display() method
        Shirt shirt = new Shirt(25.99, 'M', 'P');
        shirt.display();
    }
}
