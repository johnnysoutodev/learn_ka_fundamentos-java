package ex12_1_exercise;

public class ShoppingCart {
    public static void main(String[] args){

	// instantiate a Shirt object and call display() on the object reference
 
        
    }
}
